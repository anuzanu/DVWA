<?php

# Don't need to do anything, protction handled on the client side

?>
